# Transport Management Software
A simple browser-based transport management system inspired by the supplied screenshot.

## Run
Open `index.html` in Chrome, Safari, Edge, or Firefox.

Included:
- Transport Application v6.1 style top menu
- Touches
- A/c Reports
- Billy Reports
- Booking Reports
- Delivery Reports
- Gate Pass Reports
- Web Services
- Maintenance
- Basic booking/delivery/gate-pass data entry
